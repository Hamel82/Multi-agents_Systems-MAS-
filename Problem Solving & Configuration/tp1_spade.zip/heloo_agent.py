import asyncio
from spade.agent import Agent
from spade.behaviour import OneShotBehaviour
from spade.message import Message


# --- COMPORTEMENT DE L'AGENT ÉMETTEUR ---
class SenderBehaviour(OneShotBehaviour):
    async def run(self):
        print("Émetteur : Je prépare l'envoi du message...")
        # Remplace par le JID de ton deuxième compte
        msg = Message(to="mon_agent2_tp1@jabber.hot-chilli.net")
        msg.body = "Salut ! C'est mon premier message SPADE."

        await self.send(msg)
        print("Émetteur : Message envoyé !")


# --- COMPORTEMENT DE L'AGENT RÉCEPTEUR ---
class ReceiverBehaviour(OneShotBehaviour):
    async def run(self):
        print("Récepteur : J'attends un message...")
        # Attend le message pendant 10 secondes
        msg = await self.receive(timeout=10)
        if msg:
            print(f"Récepteur : Message reçu ! Contenu : '{msg.body}'")
        else:
            print("Récepteur : Je n'ai rien reçu après 10s.")


# --- DÉFINITION DES AGENTS ---
class SenderAgent(Agent):
    async def setup(self):
        self.add_behaviour(SenderBehaviour())


class ReceiverAgent(Agent):
    async def setup(self):
        self.add_behaviour(ReceiverBehaviour())


# --- LANCEMENT ---
async def main():
    # Remplace avec TES vrais comptes créés
    receveur = ReceiverAgent("mon_agent2_tp1@jabber.hot-chilli.net", "spade_test_2024")
    emetteur = SenderAgent("mon_agent1_tp1@jabber.hot-chilli.net", "spade_test_2024")

    await receveur.start()
    await asyncio.sleep(1)  # On laisse le récepteur s'installer
    await emetteur.start()

    await asyncio.sleep(5)  # Temps pour voir l'échange
    await receveur.stop()
    await emetteur.stop()


if __name__ == "__main__":
    asyncio.run(main())