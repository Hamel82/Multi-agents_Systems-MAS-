package eu.uemf.agents;

import jade.core.Agent;

public class HelloAgent extends Agent {
    @Override
    protected void setup() {
        System.out.println("Hello World ! I am a JADE Agent.");
        // Print the Agent's Local Name
        System.out.println("My local name is " + getAID().getLocalName());
        // Print the Agent's Globally Unique ID (GUID)
        System.out.println("My GUID is " + getAID().getName());
    }
}