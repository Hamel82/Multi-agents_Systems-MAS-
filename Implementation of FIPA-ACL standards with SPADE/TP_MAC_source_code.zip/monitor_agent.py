from spade.agent import Agent
from spade.behaviour import OneShotBehaviour
from spade.message import Message

class MonitorAgent(Agent):
    class BehaviorAsk(OneShotBehaviour):
        async def run(self):
            # 1. Construire le message QUERY-IF
            msg = Message(to="sensor@localhost")
            msg.set_metadata("performative", "query-if")
            msg.body = "What is the current temperature?"

            # 2. Envoyer
            await self.send(msg)
            print("[Monitor] QUERY-IF sent.")

            # 3. Attendre la réponse INFORM
            reply = await self.receive(timeout=10)
            if reply:
                print(f"[Monitor] Response received: {reply.body}")
            else:
                print("[Monitor] No response (timeout).")

    async def setup(self):
        print("Monitor started.")
        self.add_behaviour(self.BehaviorAsk())