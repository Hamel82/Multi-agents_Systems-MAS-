from spade.agent import Agent
from spade.behaviour import CyclicBehaviour
from spade.template import Template


class SensorAgent(Agent):
    class BehaviorQuery(CyclicBehaviour):
        async def run(self):
            # Le template garantit qu'on ne reçoit que du QUERY-IF
            msg = await self.receive(timeout=10)

            if msg:
                print(f"[Sensor] Request received: {msg.body}")

                # Préparation de la réponse
                reply = msg.make_reply()
                reply.set_metadata("performative", "inform")  # Catégorie Information

                # Simulation de la lecture du capteur
                temperature_actuelle = 25
                reply.body = f"The temperature is {temperature_actuelle}C"

                await self.send(reply)
                print("[Sensor] Reply (INFORM) sent.")

    async def setup(self):
        print("Sensor started.")

        # Filtrage strict FIPA-ACL
        template = Template()
        template.set_metadata("performative", "query-if")
        self.add_behaviour(self.BehaviorQuery(), template)