import asyncio
from sensor_agent import SensorAgent
from monitor_agent import MonitorAgent

from robot_agent import RobotAgent
from monitor_ex2 import MonitorAgentEx2


from worker_agent import WorkerAgent
from monitor_ex3 import MonitorAgentEx3


async def main():
    """
    # ── Exercise 1 — QUERY-IF / INFORM ──────────────────────────────────────
    print("\n" + "="*50)
    print("EXERCISE 1 — QUERY-IF / INFORM")
    print("="*50)

    sensor  = SensorAgent("sensor@localhost",  "password")
    monitor = MonitorAgent("monitor@localhost", "password")

    await sensor.start()
    await asyncio.sleep(1)
    await monitor.start()
    await asyncio.sleep(5)

    await monitor.stop()
    await sensor.stop()

    """

    """
    # ── Exercise 2 — REQUEST / AGREE / REFUSE ───────────────────────────────
    print("\n" + "="*50)
    print("EXERCISE 2 — REQUEST / AGREE / REFUSE")
    print("="*50)

    robot    = RobotAgent("robot@localhost",    "password", battery_level=80)
    monitor2 = MonitorAgentEx2("monitor2@localhost", "password")

    await robot.start()
    await asyncio.sleep(1)
    await monitor2.start()
    await asyncio.sleep(40)

    await monitor2.stop()
    await robot.stop()
    """


    # ── Exercise 3 — CFP / PROPOSE / ACCEPT / REJECT ────────────────────────
    print("\n" + "="*50)
    print("EXERCISE 3 — CFP / PROPOSE / ACCEPT / REJECT")
    print("="*50)

    worker1  = WorkerAgent("worker1@localhost", "password", cost=10)
    worker2  = WorkerAgent("worker2@localhost", "password", cost=5)
    monitor3 = MonitorAgentEx3("monitor3@localhost", "password")

    await worker1.start()
    await worker2.start()
    await asyncio.sleep(1)
    await monitor3.start()
    await asyncio.sleep(10)

    await monitor3.stop()
    await worker1.stop()
    await worker2.stop()


if __name__ == "__main__":
    asyncio.run(main())