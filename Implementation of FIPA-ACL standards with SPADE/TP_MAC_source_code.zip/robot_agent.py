import asyncio
from spade.agent import Agent
from spade.behaviour import CyclicBehaviour
from spade.template import Template

class RobotAgent(Agent):
    def __init__(self, jid, password, battery_level=100):
        super().__init__(jid, password)
        self.battery_level = battery_level
        # Scénario prédéfini : quel mouvement déclenche un obstacle
        self.obstacle_on_move = 2  # le 2ème mouvement aura un obstacle
        self.move_count = 0

    class BehaviorRequest(CyclicBehaviour):
        async def run(self):
            msg = await self.receive(timeout=15)
            if msg:
                self.agent.move_count += 1
                move_n = self.agent.move_count
                print(f"\n[Robot] REQUEST #{move_n} received: {msg.body}")
                print(f"[Robot] Battery level: {self.agent.battery_level}%")

                reply = msg.make_reply()

                if self.agent.battery_level > 20:
                    # AGREE
                    reply.set_metadata("performative", "agree")
                    reply.body = f"Movement #{move_n} authorized. Execution in progress."
                    await self.send(reply)
                    print(f"[Robot] AGREE sent for movement #{move_n}.")

                    # Simulation du mouvement
                    await asyncio.sleep(2)

                    # Décharge la batterie
                    self.agent.battery_level -= 15
                    print(f"[Robot] Battery after movement: {self.agent.battery_level}%")

                    # Obstacle sur le mouvement prédéfini
                    obstacle = (move_n == self.agent.obstacle_on_move)

                    inform = msg.make_reply()
                    if not obstacle:
                        inform.set_metadata("performative", "inform")
                        inform.body = (
                            f"Movement #{move_n} completed successfully. "
                            f"Battery: {self.agent.battery_level}%"
                        )
                        print(f"[Robot] INFORM (success) sent for movement #{move_n}.")
                    else:
                        inform.set_metadata("performative", "failure")
                        inform.body = (
                            f"Movement #{move_n} failed: obstacle detected. "
                            f"Battery: {self.agent.battery_level}%"
                        )
                        print(f"[Robot] FAILURE (obstacle) sent for movement #{move_n}.")

                    await self.send(inform)

                else:
                    # REFUSE
                    reply.set_metadata("performative", "refuse")
                    reply.body = (
                        f"Movement #{move_n} refused: battery too low "
                        f"({self.agent.battery_level}%). Minimum required: 20%."
                    )
                    await self.send(reply)
                    print(f"[Robot] REFUSE sent for movement #{move_n} (battery: {self.agent.battery_level}%).")

    async def setup(self):
        print(f"[Robot] Started. Initial battery: {self.battery_level}%")
        template = Template()
        template.set_metadata("performative", "request")
        self.add_behaviour(self.BehaviorRequest(), template)