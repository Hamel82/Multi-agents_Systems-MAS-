import asyncio
from spade.agent import Agent
from spade.behaviour import OneShotBehaviour
from spade.message import Message

MOVES = [
    "Move to position (5, 3)",
    "Move to position (8, 1)",
    "Move to position (2, 6)",
    "Move to position (4, 4)",
    "Move to position (9, 2)",
]

class MonitorAgentEx2(Agent):
    class BehaviorSendRequest(OneShotBehaviour):
        async def run(self):
            for i, move in enumerate(MOVES, 1):
                print(f"\n[Monitor] Sending REQUEST #{i}: {move}")

                msg = Message(to="robot@localhost")
                msg.set_metadata("performative", "request")
                msg.body = move
                await self.send(msg)

                # Attente AGREE ou REFUSE
                reply = await self.receive(timeout=10)
                if reply:
                    perf = reply.get_metadata("performative")
                    print(f"[Monitor] Response #{i} ({perf.upper()}): {reply.body}")

                    if perf == "agree":
                        # Attente INFORM ou FAILURE
                        result = await self.receive(timeout=15)
                        if result:
                            perf2 = result.get_metadata("performative")
                            print(f"[Monitor] Result #{i} ({perf2.upper()}): {result.body}")

                # Pause entre chaque mouvement
                await asyncio.sleep(1)

            print("\n[Monitor] All movement requests completed.")

    async def setup(self):
        print("[Monitor Ex2] Started.")
        self.add_behaviour(self.BehaviorSendRequest())