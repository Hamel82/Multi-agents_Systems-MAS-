from spade.agent import Agent
from spade.behaviour import CyclicBehaviour, OneShotBehaviour
from spade.message import Message
from spade.template import Template

class MonitorAgentEx3(Agent):
    class BehaviorCFP(OneShotBehaviour):
        async def run(self):
            workers = ["worker1@localhost", "worker2@localhost"]

            # 1. Envoi du CFP aux deux workers
            for worker_jid in workers:
                cfp = Message(to=worker_jid)
                cfp.set_metadata("performative", "cfp")
                cfp.body = "CNN Training"
                await self.send(cfp)
                print(f"[Monitor] CFP sent to {worker_jid}")

            # 2. Collecte des propositions (template filtre sur "propose")
            proposals = []
            for _ in workers:
                proposal = await self.receive(timeout=15)
                if proposal:
                    cost = int(proposal.body.split(":")[1].strip().split()[0])
                    proposals.append((proposal, cost))
                    print(f"[Monitor] PROPOSE received from {proposal.sender}: {proposal.body}")

            if not proposals:
                print("[Monitor] No proposals received.")
                return

            # 3. Comparaison — on choisit le moins cher
            proposals.sort(key=lambda x: x[1])  # tri par coût croissant
            best_proposal   = proposals[0][0]
            other_proposals = [p[0] for p in proposals[1:]]

            # 4. Envoi accept-proposal au gagnant
            accept = best_proposal.make_reply()
            accept.set_metadata("performative", "accept-proposal")
            accept.body = f"Your proposal is accepted. Please start CNN Training."
            await self.send(accept)
            print(f"[Monitor] ACCEPT-PROPOSAL sent to {best_proposal.sender}")

            # 5. Envoi reject-proposal aux autres
            for loser in other_proposals:
                reject = loser.make_reply()
                reject.set_metadata("performative", "reject-proposal")
                reject.body = "Your proposal was not selected."
                await self.send(reject)
                print(f"[Monitor] REJECT-PROPOSAL sent to {loser.sender}")

    async def setup(self):
        print("Monitor (Ex3) started.")
        # Template : écoute uniquement les "propose"
        template = Template()
        template.set_metadata("performative", "propose")
        self.add_behaviour(self.BehaviorCFP(), template)