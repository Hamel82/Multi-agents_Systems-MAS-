from spade.agent import Agent
from spade.behaviour import CyclicBehaviour
from spade.template import Template

class WorkerAgent(Agent):
    def __init__(self, jid, password, cost):
        super().__init__(jid, password)
        self.cost = cost

    class BehaviorCFP(CyclicBehaviour):
        async def run(self):
            msg = await self.receive(timeout=10)
            if msg:
                print(f"[Worker {self.agent.jid.local}] CFP received: {msg.body}")
                reply = msg.make_reply()
                reply.set_metadata("performative", "propose")
                reply.body = f"Cost: {self.agent.cost} time units"
                await self.send(reply)
                print(f"[Worker {self.agent.jid.local}] PROPOSE sent — {reply.body}")

    class BehaviorDecision(CyclicBehaviour):
        async def run(self):
            msg = await self.receive(timeout=15)
            if msg:
                perf = msg.get_metadata("performative")
                print(f"[Worker {self.agent.jid.local}] Decision received: {perf.upper()}")

    async def setup(self):
        print(f"Worker {self.jid.local} started.")

        # Template pour CFP
        template_cfp = Template()
        template_cfp.set_metadata("performative", "cfp")
        self.add_behaviour(self.BehaviorCFP(), template_cfp)

        # Template pour la décision
        template_decision = Template()
        template_decision.set_metadata("performative", "accept-proposal")

        template_decision2 = Template()
        template_decision2.set_metadata("performative", "reject-proposal")

        # On écoute accept OU reject
        self.add_behaviour(self.BehaviorDecision(), template_decision | template_decision2)
