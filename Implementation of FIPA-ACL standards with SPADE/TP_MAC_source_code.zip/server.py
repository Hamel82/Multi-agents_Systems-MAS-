import asyncio
import logging
from pyjabber.server import Server

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

async def main():
    print("Initialisation du serveur XMPP pyjabber...")
    server = Server()
    await server.start()
    print("Serveur XMPP en ligne ! En attente des agents...")

    try:
        while True:
            await asyncio.sleep(3600)
    except KeyboardInterrupt:
        print("\nArrêt du serveur XMPP.")

if __name__ == "__main__":
    asyncio.run(main())