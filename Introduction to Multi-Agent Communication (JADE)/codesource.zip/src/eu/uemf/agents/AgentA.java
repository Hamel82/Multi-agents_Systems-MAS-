package eu.uemf.agents;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

//exo1
public class AgentA extends Agent {

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " started and will send a message...");

        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                // Create INFORM message
                ACLMessage msg = new ACLMessage(ACLMessage.INFORM);

                // Set receiver (AgentB)
                msg.addReceiver(new AID("agent1", AID.ISLOCALNAME));

                // Set content
                msg.setContent("Hello B!");

                // Send message
                send(msg);

                System.out.println(getLocalName() + " sent message to agentB");
            }
        });
    }
}


/*
//EXO2
public class AgentA extends Agent {

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " started and will send a message...");

        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                // Create INFORM message
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);

                // Set receiver (AgentB)
                msg.addReceiver(new AID("agent1", AID.ISLOCALNAME));

                // Set content
                msg.setContent("Hello B! \n What is the temperature?");

                // Send message
                send(msg);

                System.out.println(getLocalName() + " sent message to agentB");
                System.out.println(getLocalName() + " waiting for response...");
            }
        });

        // Comportement de la réception
        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                ACLMessage msg = receive(); // check inbox

                if (msg != null) {
                    System.out.println(getLocalName() + " received message:");
                    System.out.println("From: " + msg.getSender().getLocalName());
                    System.out.println("Content: " + msg.getContent());
                }else {
                    block();
                }
            }
        });
    }
}*/
