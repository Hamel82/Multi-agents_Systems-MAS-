package eu.uemf.agents;


import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.core.behaviours.*;

public class seller2 extends Agent {

    // Prix fixe - différent pour chaque seller
    private int myPrice;
    private String sellerName;

    @Override
    protected void setup() {
        // Récupérer le prix depuis les arguments ou utiliser un prix par défaut
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            myPrice = Integer.parseInt((String) args[0]);
        } else {
            // Prix par défaut selon le nom
            myPrice = getLocalName().equals("Seller1") ? 500 : 450;
        }

        sellerName = getLocalName();
        System.out.println(sellerName + " started with price: " + myPrice);

        // Comportement principal: écouter CFP et répondre
        addBehaviour(new CyclicBehaviour(this) {

            private MessageTemplate cfpTemplate =
                MessageTemplate.MatchPerformative(ACLMessage.CFP);

            @Override
            public void action() {
                ACLMessage msg = receive(cfpTemplate);

                if (msg != null) {
                    // Reçu un CFP
                    System.out.println(sellerName + " received CFP from "
                        + msg.getSender().getLocalName());

                    // Répondre avec PROPOSE
                    ACLMessage propose = msg.createReply();
                    propose.setPerformative(ACLMessage.PROPOSE);
                    propose.setContent(String.valueOf(myPrice));
                    send(propose);

                    System.out.println(sellerName + " sent PROPOSE with price: " + myPrice);

                    // Passer en mode écoute pour ACCEPT/REJECT
                    addBehaviour(new OneShotBehaviour(myAgent) {

                        private MessageTemplate decisionTemplate =
                            MessageTemplate.or(
                                MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL),
                                MessageTemplate.MatchPerformative(ACLMessage.REJECT_PROPOSAL)
                            );

                        @Override
                        public void action() {
                            // Attendre la décision (bloquant)
                            ACLMessage decision = blockingReceive(decisionTemplate);

                            if (decision.getPerformative() == ACLMessage.ACCEPT_PROPOSAL) {
                                System.out.println(sellerName + ": Hooray, I won the deal! Price = " + myPrice);

                                // Envoyer confirmation
                                ACLMessage confirm = decision.createReply();
                                confirm.setPerformative(ACLMessage.INFORM);
                                confirm.setContent("Deal confirmed - delivering parts");
                                send(confirm);

                            } else {
                                System.out.println(sellerName + ": Sorry, I lost the deal. Better luck next time!");
                            }
                        }
                    });

                } else {
                    block();
                }
            }
        });
    }
}