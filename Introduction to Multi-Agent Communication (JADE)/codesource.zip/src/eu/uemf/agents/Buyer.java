package eu.uemf.agents;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.core.behaviours.*;

public class Buyer extends Agent {

    private int proposalCount = 0;
    private int bestPrice = Integer.MAX_VALUE;
    private AID bestSeller = null;

    // Stockage des deux propositions pour pouvoir répondre aux deux
    private ACLMessage firstProposal = null;
    private ACLMessage secondProposal = null;

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " (Buyer) started...");

        // Phase 1: Envoyer les CFP aux deux sellers
        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                // CFP pour Seller 1
                ACLMessage cfp1 = new ACLMessage(ACLMessage.CFP);
                cfp1.addReceiver(new AID("seller1", AID.ISLOCALNAME));
                cfp1.setContent("Call for proposal - Please send your price");
                send(cfp1);
                System.out.println(getLocalName() + " sent CFP to Seller1");

                // CFP pour Seller 2
                ACLMessage cfp2 = new ACLMessage(ACLMessage.CFP);
                cfp2.addReceiver(new AID("seller2", AID.ISLOCALNAME));
                cfp2.setContent("Call for proposal - Please send your price");
                send(cfp2);
                System.out.println(getLocalName() + " sent CFP to Seller2");
            }
        });

        // Phase 2: Écouter les PROPOSE et décider
        addBehaviour(new CyclicBehaviour(this) {

            private MessageTemplate proposeTemplate =
                MessageTemplate.MatchPerformative(ACLMessage.PROPOSE);

            @Override
            public void action() {
                // Filtrer uniquement les messages PROPOSE
                ACLMessage msg = receive(proposeTemplate);

                if (msg != null) {
                    // Extraire le prix
                    int price = Integer.parseInt(msg.getContent());
                    System.out.println(getLocalName() + " received PROPOSE from "
                        + msg.getSender().getLocalName() + " with price: " + price);

                    proposalCount++;

                    // Stocker les deux propositions
                    if (proposalCount == 1) {
                        firstProposal = msg;
                    } else {
                        secondProposal = msg;
                    }

                    // Comparer les prix et garde la meilleure proposition et du bestseller
                    if (price < bestPrice) {
                        bestPrice = price;
                        bestSeller = msg.getSender();
                    }

                    // Si on a reçu les 2 propositions alors prendre décision
                    if (proposalCount == 2) {
                        System.out.println("========================================");
                        System.out.println("Comparison: ");
                        System.out.println("  Seller1 price: " + firstProposal.getContent());
                        System.out.println("  Seller2 price: " + secondProposal.getContent());
                        System.out.println("Winner: " + bestSeller.getLocalName() + " with price " + bestPrice);
                        System.out.println("========================================");

                        // Déterminer gagnant et perdant
                        ACLMessage winnerProposal, loserProposal;

                        if (firstProposal.getSender().equals(bestSeller)) {
                            winnerProposal = firstProposal;
                            loserProposal = secondProposal;
                        } else {
                            winnerProposal = secondProposal;
                            loserProposal = firstProposal;
                        }

                        // Envoyer ACCEPT_PROPOSAL au gagnant
                        ACLMessage accept = winnerProposal.createReply();
                        accept.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
                        accept.setContent("Congratulations! You won the deal.");
                        send(accept);
                        System.out.println(getLocalName() + " sent ACCEPT_PROPOSAL to "
                            + bestSeller.getLocalName());

                        // Envoyer REJECT_PROPOSAL au perdant
                        ACLMessage reject = loserProposal.createReply();
                        reject.setPerformative(ACLMessage.REJECT_PROPOSAL);
                        reject.setContent("Sorry, your price was too high. Better luck next time!");
                        send(reject);
                        System.out.println(getLocalName() + " sent REJECT_PROPOSAL to "
                            + loserProposal.getSender().getLocalName());

                        // Arrêter ce comportement
                        removeBehaviour(this);
                        System.out.println(getLocalName() + ": Decision made, listener stopped.");
                    }

                } else {
                    block();
                }
            }
        });
    }
}