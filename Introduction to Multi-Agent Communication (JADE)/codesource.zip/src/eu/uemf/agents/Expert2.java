package eu.uemf.agents;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Expert2 extends Agent {

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " started and waiting for messages...");

        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                ACLMessage msg = receive(); // check inbox

                if (msg != null) {
                    System.out.println(getLocalName() + " received message:");
                    System.out.println("From: " + msg.getSender().getLocalName());
                    System.out.println("Performative: " + ACLMessage.getPerformative(msg.getPerformative()));
                    System.out.println("Content: " + msg.getContent());

                    // Vérifier si c'est un REQUEST
                    if (msg.getPerformative() == ACLMessage.REQUEST) {

                        // Créer la réponse automatique avec createReply()
                        ACLMessage reply = msg.createReply();

                        // Définir la performative de la réponse
                        reply.setPerformative(ACLMessage.INFORM);

                        // Définir le contenu de la réponse
                        reply.setContent("Hello Coordinator ! I am "+ getLocalName() + " I received your request.");

                        // Envoyer la réponse
                        send(reply);

                        System.out.println(getLocalName() + " sent reply to " + msg.getSender().getLocalName());
                    }

                } else {
                    block();
                }
            }
        });
    }
}
