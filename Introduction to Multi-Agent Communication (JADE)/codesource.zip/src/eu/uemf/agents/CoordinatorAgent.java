package eu.uemf.agents;


import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class CoordinatorAgent extends Agent {
    private int counter = 0;

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " started and will send messages...");

        // envoie des deux requêtes aux Experts
        addBehaviour(new OneShotBehaviour() {
            @Override
            public void action() {
                // Create REQUEST message
                ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);

                // Set receiver (AgentB)
                msg.addReceiver(new AID("agent1", AID.ISLOCALNAME));

                // Set content
                msg.setContent("Hello B!");

                // Send message
                send(msg);

                // Create second REQUEST message
                ACLMessage msg2 = new ACLMessage(ACLMessage.REQUEST);

                // Set receiver (AgentB)
                msg2.addReceiver(new AID("agent2", AID.ISLOCALNAME));

                // Set content
                msg2.setContent("Hello C!");

                // Send message
                send(msg2);


                System.out.println(getLocalName() + " sent messages to Expert1 and Expert2");
            }
        });
        // Listening of response
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive(); // check inbox

                if (msg != null) {
                    // Vérifier si c'est un INFORM
                    if (msg.getPerformative() == ACLMessage.INFORM) {

                        // Incrémenter le compteur
                        counter++;

                        System.out.println(getLocalName() + " received INFORM from "
                            + msg.getSender().getLocalName());
                        System.out.println("Content: " + msg.getContent());
                        System.out.println("Counter = " + counter);

                        // Si le compteur atteint 2
                        if (counter == 2) {
                            System.out.println("========================================");
                            System.out.println("GLOBAL RESULT: All replies completed!");
                            System.out.println("Total INFORM received: " + counter);
                            System.out.println("========================================");

                            // Détruire ce comportement
                            myAgent.removeBehaviour(this); // myAgent  = CoordinatorAgent
                            System.out.println(getLocalName() + " : Listener behaviour removed.");
                        }
                    }

                } else {
                    block();
                }
            }
        });
    }
}
